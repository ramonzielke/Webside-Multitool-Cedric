document.getElementById("gradeForm").addEventListener("submit", function(event) {
  event.preventDefault();
  calculateAverage();
});

function calculateAverage() {
  var deutschGrade = parseFloat(document.getElementById("deutsch").value);
  var franzoesischGrade = parseFloat(document.getElementById("franzoesisch").value);
  var englischGrade = parseFloat(document.getElementById("englisch").value);
  var mathematikGrade = parseFloat(document.getElementById("mathematik").value);
  var naturwissenschaftenGrade = parseFloat(document.getElementById("naturwissenschaften").value);
  var geschichteGrade = parseFloat(document.getElementById("geschichte").value);
  var geografieGrade = parseFloat(document.getElementById("geografie").value);
  var wirtschaft_rechtGrade = parseFloat(document.getElementById("wirtschaft_recht").value);
  var gestaltenGrade = parseFloat(document.getElementById("gestalten").value);
  var sportGrade = parseFloat(document.getElementById("sport").value);

  var average = ((deutschGrade * 2) + franzoesischGrade + englischGrade + mathematikGrade +
    (naturwissenschaftenGrade * 2) + geschichteGrade + geografieGrade + wirtschaft_rechtGrade +
    gestaltenGrade + sportGrade) / 12;

  var finalGrade = getFinalGrade(average);

  document.getElementById("result").innerHTML = "Durchschnittsnote: " + average.toFixed(1) + " - Endnote: " + finalGrade;
}

function getFinalGrade(average) {
  if (average >= 5.75) {
    return "6";
  } else if (average >= 5.25) {
    return "5.5";
  } else if (average >= 4.75) {
    return "5";
  } else if (average >= 4.25) {
    return "4.5";
  } else if (average >= 3.75) {
    return "4";
  } else if (average >= 3.25) {
    return "3.5";
  } else if (average >= 2.75) {
    return "3";
  } else if (average >= 2.25) {
    return "2.5";
  } else if (average >= 1.75) {
    return "2";
  } else {
    return "1";
  }
}


function addToDisplay(value) {
  var display = document.getElementById("display");
  display.value += value;
}

function calculate() {
  var display = document.getElementById("display");
  var result = eval(display.value);
  display.value = result;
}


function appendChar(char) {
    document.getElementById('display').value += char;
}

function clearDisplay() {
    document.getElementById('display').value = '';
}

function deleteChar() {
    var display = document.getElementById('display');
    display.value = display.value.slice(0, -1);
}

function calculate() {
    var display = document.getElementById('display');
    var expression = display.value;

    try {
        var result = eval(expression);
        display.value = result;
    } catch (error) {
        display.value = 'Error';
    }
}
