// Überprüfung, ob der Benutzer bereits den Cookie-Banner akzeptiert hat
function hasAcceptedCookies() {
  return localStorage.getItem('cookiesAccepted');
}

// Weiterleitung zur troll.html-Seite
function redirectToTrollPage() {
  window.location.href = 'troll2.html';
}

// Event Listener für den Klick auf den "Akzeptieren"-Button
document.getElementById('accept-cookies').addEventListener('click', function() {
  localStorage.setItem('cookiesAccepted', 'true');
  redirectToTrollPage();
});

// Event Listener für den Klick auf den "Ablehnen"-Button
document.getElementById('reject-cookies').addEventListener('click', redirectToTrollPage);

// Überprüfen, ob der Benutzer bereits den Cookie-Banner akzeptiert hat
if (!hasAcceptedCookies()) {
  document.getElementById('cookie-banner').style.display = 'block';
}
