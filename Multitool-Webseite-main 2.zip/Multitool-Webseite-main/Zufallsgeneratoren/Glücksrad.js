var namenArray = [];
var rotationInProgress = false;

function startRotation() {
  if (namenArray.length > 1 && !rotationInProgress) {
    rotationInProgress = true;

    var randomAngle = Math.floor(Math.random() * 360) + 720; // Zufällige Anzahl von Umdrehungen (mindestens 2)
    var sectorAngle = 360 / namenArray.length;
    var sectorIndex = Math.floor((360 - (randomAngle % 360)) / sectorAngle); // Index des ausgewählten Sektors

    // Rotationsanimation hinzufügen
    var rotationDuration = 5; // Dauer der Rotation in Sekunden
    var rotationEase = Power4.easeOut; // Easing-Funktion für die Rotation (kann angepasst werden)

    TweenMax.to('#gluecksrad', rotationDuration, {
      rotation: randomAngle,
      ease: rotationEase,
      onComplete: function() {
        rotationInProgress = false;
        alert('Gewonnen: ' + namenArray[sectorIndex]);
        resetRotation();
      }
    });
  } else if (rotationInProgress) {
    alert('Die Rotation ist bereits im Gange. Bitte warte, bis sie abgeschlossen ist.');
  } else {
    alert('Bitte geben Sie mindestens zwei Namen ein.');
  }
}

function resetRotation() {
  TweenMax.set('#gluecksrad', { rotation: 0 });
}

function updateNamen() {
  var namenInput = document.getElementById('namenInput').value;
  namenArray = namenInput.split(',').map(function(item) {
    return item.trim();
  });

  var rad = document.getElementById('gluecksrad');
  rad.innerHTML = '';

  namenArray.forEach(function(name, index) {
    var sector = document.createElement('div');
    sector.className = 'rad-sektor';
    sector.style.transform = 'rotate(' + (index * (360 / namenArray.length)) + 'deg)';
    sector.innerHTML = '<span>' + name + '</span>';
    rad.appendChild(sector);
  });
}

document.getElementById('namenInput').addEventListener('input', updateNamen);
