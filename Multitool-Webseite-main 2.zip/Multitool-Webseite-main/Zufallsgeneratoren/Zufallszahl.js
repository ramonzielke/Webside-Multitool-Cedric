document.getElementById('generate-btn').addEventListener('click', function() {
    var min = parseInt(document.getElementById('min').value);
    var max = parseInt(document.getElementById('max').value);

    if (min >= max) {
        alert('Das Minimum muss kleiner als das Maximum sein.');
        return;
    }

    var randomNum = Math.floor(Math.random() * (max - min + 1)) + min;
    document.getElementById('result').textContent = 'Generierte Zahl: ' + randomNum;
});
